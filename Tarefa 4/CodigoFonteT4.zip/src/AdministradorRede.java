package Tarefa4;
import java.util.Scanner;

    public class AdministradorRede extends Tarefa4.FuncionarioTI {
        private String certificacao;
        private String sistemaOperacionalResponsavel;

        public AdministradorRede(String nome, String matricula, Scanner scanner) {
            super(nome, matricula, Tarefa4.TipoFuncionario.ADMINISTRADOR_REDE);

            System.out.println("\nCadastro de Administrador de Rede");

            System.out.print("Informe a certificação principal: ");
            this.certificacao = scanner.nextLine();

            System.out.print("Informe o sistema operacional responsável: ");
            this.sistemaOperacionalResponsavel = scanner.nextLine();

            System.out.println("Administrador de Rede " + nome + " cadastrado.");
        }

        public void monitorarRede() {
            System.out.println(this.nome + " monitorou a rede e sistemas.");
        }

        public void realizarBackup() {
            System.out.println(this.nome + " realizou um backup do sistema " + this.sistemaOperacionalResponsavel + ".");
        }

        @Override
        public void exibirDados() {
            super.exibirDados();
            System.out.println("Certificação: " + this.certificacao);
            System.out.println("Sistema Operacional Responsável: " + this.sistemaOperacionalResponsavel);
        }

        // gets e sets de AdministradorRede
        public String getCertificacao() {
            return certificacao;
        }

        public void setCertificacao(String certificacao) {
            this.certificacao = certificacao;
        }

        public String getSistemaOperacionalResponsavel() {
            return sistemaOperacionalResponsavel;
        }

        public void setSistemaOperacionalResponsavel(String sistemaOperacionalResponsavel) {
            this.sistemaOperacionalResponsavel = sistemaOperacionalResponsavel;
        }
    }