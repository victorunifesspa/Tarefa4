package Tarefa4;

import java.util.Scanner;


    public class Desenvolvedor extends Tarefa4.FuncionarioTI {

        private Tarefa4.Nivel nivel;
        private String linguagemPrincipal;

        public Desenvolvedor(String nome, String matricula, Scanner scanner) {

            super(nome, matricula, Tarefa4.TipoFuncionario.DESENVOLVEDOR);

            System.out.println("\n- Cadastro de Desenvolvedor: Especificidades -");

            System.out.print("Informe a linguagem de programação principal: ");
            this.linguagemPrincipal = scanner.nextLine();
            boolean nivelValido = false;
            while (!nivelValido) {
                System.out.print("Informe o nível (JUNIOR, PLENO, SENIOR): ");
                String nivelInput = scanner.nextLine().trim().toUpperCase();
                try {
                    this.nivel = Tarefa4.Nivel.valueOf(nivelInput);
                    nivelValido = true;
                } catch (IllegalArgumentException e) {
                    System.out.println("Nível inválido. Por favor, escolha entre: JUNIOR, PLENO ou SENIOR.");
                }
            }
            System.out.println("Desenvolvedor " + nome + " cadastrado.");
        }

        public void desenvolverProjeto() {
            System.out.println(this.nome + " desenvolve um projeto em " + this.linguagemPrincipal + ".");
        }

        public void atualizarProjeto() {
            System.out.println(this.nome + " atualiza um projeto.");
        }

        public void exibirTecnologiasUsadas() {
            System.out.println(this.nome + " usa principalmente " + this.linguagemPrincipal + ".");
        }

        public void revisarCodigo() {
            System.out.println(this.nome + " revisou o código.");
        }

        // override, redefinicao em exibirDados()
        @Override
        public void exibirDados() {
            super.exibirDados();
            System.out.println("Linguagem Principal: " + this.linguagemPrincipal);
            System.out.println("Nível: " + this.nivel.name());
        }

        // get e set de Desenvolvedor, usados p possivel atualizacao de  cadastro
        public Tarefa4.Nivel getNivel() {
            return nivel;
        }

        public void setNivel(Tarefa4.Nivel nivel) {
            this.nivel = nivel;
        }

        public String getLinguagemPrincipal() {
            return linguagemPrincipal;
        }

        public void setLinguagemPrincipal(String linguagemPrincipal) {
            this.linguagemPrincipal = linguagemPrincipal;
        }
    }