package Tarefa4;

public enum Nivel {
    JUNIOR,
    PLENO,
    SENIOR;
}