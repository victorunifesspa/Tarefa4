package Tarefa4;
import java.util.Scanner;

public class FuncionarioTI {
    protected String nome;
    protected String matricula;
    protected Tarefa4.TipoFuncionario funcao;

    public FuncionarioTI(String nome, String matricula, Tarefa4.TipoFuncionario funcao) {
        this.nome = nome;
        this.matricula = matricula;
        this.funcao = funcao;
    }

    public void exibirDados() {
        System.out.println("Funcionario encontrado:");
        System.out.println("Nome: " + this.nome);
        System.out.println("Matrícula: " + this.matricula);
        System.out.println("Função: " + this.funcao.name());
    }

    public int atualizarCadastro(Scanner scanner) {
        System.out.println("\n--- Atualizar Cadastro Básico de " + this.nome + " ---");
        System.out.print("Novo Nome (" + this.nome + "): ");
        String novoNome = scanner.nextLine();


        System.out.print("Nova Matrícula (" + this.matricula + "): ");
        String novaMatricula = scanner.nextLine();

    return 0;
    }
}