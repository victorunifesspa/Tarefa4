package Tarefa4;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("CADASTRO DE FUNCIONÁRIOS");

        System.out.println("\nCadastro do Desenvolvedor ");
        System.out.print("Digite o nome do Desenvolvedor: ");
        String nomeDev = scanner.nextLine();
        System.out.print("Digite a matrícula do Desenvolvedor: ");
        String matriculaDev = scanner.nextLine();

        Tarefa4.Desenvolvedor dev1 = new Tarefa4.Desenvolvedor(nomeDev, matriculaDev, scanner);

        System.out.println("\nCadastro do Administrador de Rede");
        System.out.print("Digite o nome do Administrador de Rede: ");
        String nomeAdm = scanner.nextLine();
        System.out.print("Digite a matrícula do Administrador de Rede: ");
        String matriculaAdm = scanner.nextLine();

        Tarefa4.AdministradorRede adm1 = new Tarefa4.AdministradorRede(nomeAdm, matriculaAdm, scanner);

        System.out.println("\nExibindo Dados dos Funcionários Cadastrados");

        System.out.println("\nDados do Desenvolvedor ");
        dev1.exibirDados();

        System.out.println("\nDados do Administrador de Rede");
        adm1.exibirDados();

        System.out.println("\nDemonstração de Operações Específicas");
        dev1.desenvolverProjeto();
        adm1.monitorarRede();

        scanner.close();
    }
}