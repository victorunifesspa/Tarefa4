package Tarefa4;

public enum TipoFuncionario {
    DESENVOLVEDOR,
    ADMINISTRADOR_REDE;
}